const STORAGE_KEY = "transfer_v1";

const bgdef = "images/bgdef.png";
const bg500mb = "images/bg500mb.png";
const bg1gb = "images/bg1gb.png";

const KWH_PER_MB = 0.0000165;
const KGCO2_PER_KWH = 0.472;
const DAILY_INTERNET_USERS = 6000000000;
const SHARE = 0.10;

const ICE_DENSITY = 917;
const OLYMPIC_POOL_M3 = 2500;
//İnfo butonu 
const infoButton = document.createElement("div");
infoButton.innerText = "i";
infoButton.id = "info-btn";
const infoBox = document.createElement("div");
infoBox.id = "info-box";
infoBox.innerText = `Bu sonuçlar, çeşitli algoritmalar kullanılarak oluşturulmuş tahmini değerlerdir ve kesin sonuçlar değildir.
Hesaplamalar, dijital veri kullanımı ile karbon emisyonu arasındaki ilişkiye dayalı modeller üzerinden yapılmıştır.
Amaç, dijital alışkanlıkların çevre üzerindeki etkisini daha anlaşılır hale getiren bir senaryo sunmaktır.`;
const header = document.querySelector(".hdr");
header.appendChild(infoButton);
header.appendChild(infoBox);
infoButton.addEventListener("click", () => {
    infoBox.style.display =
        infoBox.style.display === "block" ? "none" : "block";
});

function pickBgByTotalBytes(totalDownBytes) {
  const mb = bytesToMB(totalDownBytes);
  if (mb >= 1024) return bg1gb;
  if (mb >= 500) return bg500mb;
  return bgdef;
}

function applyPopupBackground(bgPath) {
  const el = document.getElementById("bg");
  if (!el) return;
  el.style.backgroundImage = `url("${chrome.runtime.getURL(bgPath)}")`;
}

function bytesToPretty(bytes) {
  const b = Number(bytes || 0);

  if (b < 1024) return `${b} B`;

  const kb = b / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;

  const mb = kb / 1024;
  if (mb < 1024) return `${mb.toFixed(1)} MB`;

  const gb = mb / 1024;
  return `${gb.toFixed(2)} GB`;
}

function prettyDate(yyyyMmDd) {
  if (!yyyyMmDd || typeof yyyyMmDd !== "string" || !yyyyMmDd.includes("-")) {
    return "—";
  }

  const [y, m, d] = yyyyMmDd.split("-");
  return `${d}.${m}.${y}`;
}

function bytesToMB(bytes) {
  return Number(bytes || 0) / (1024 * 1024);
}

function fmtKg(kg) {
  if (!isFinite(kg)) return "—";

  const a = Math.abs(kg);

  if (a < 0.001) return `${(kg * 1e6).toFixed(0)} mg CO₂`;
  if (a < 1) return `${(kg * 1000).toFixed(1)} g CO₂`;
  if (a < 1000) return `${kg.toFixed(2)} kg CO₂`;

  return `${(kg / 1000).toFixed(2)} t CO₂`;
}

function storageGet(key) {
  return new Promise((resolve) => {
    chrome.storage.local.get(key, (res) => {
      resolve(res ? res[key] : null);
    });
  });
}

async function loadImpactMeta() {
  const url = chrome.runtime.getURL("impact_meta.json");
  const res = await fetch(url);

  if (!res.ok) {
    throw new Error(`impact_meta.json okunamadı: ${res.status}`);
  }

  return await res.json();
}

function computeFootprintFromDownBytes(totalDownBytes) {
  const mb = bytesToMB(totalDownBytes);
  const kwh = mb * KWH_PER_MB;
  const kgco2 = kwh * KGCO2_PER_KWH;

  return { mb, kwh, kgco2 };
}

function computeScenarioGtCO2PerYear(kgco2PerUserPerDay) {
  const kgco2Day = kgco2PerUserPerDay * DAILY_INTERNET_USERS * SHARE;
  return (kgco2Day * 365) / 1e12;
}

function formatMassFromGt(gt) {
  if (!isFinite(gt)) return "—";

  const kg = Math.abs(gt) * 1e12;

  if (kg >= 1e9) return `${(kg / 1e9).toFixed(2)} milyar kg`;
  if (kg >= 1e6) return `${(kg / 1e6).toFixed(2)} milyon kg`;
  if (kg >= 1000) return `${(kg / 1000).toFixed(2)} ton`;

  return `${kg.toFixed(0)} kg`;
}

function calculatePoolsFromGt(gt) {
  const kg = Math.abs(gt) * 1e12;
  const volumeM3 = kg / ICE_DENSITY;
  return volumeM3 / OLYMPIC_POOL_M3;
}

function formatPools(poolCount) {
  if (!isFinite(poolCount)) return "—";
  if (poolCount >= 100) return `${Math.round(poolCount)}`;
  if (poolCount >= 10) return `${poolCount.toFixed(1)}`;
  return `${poolCount.toFixed(2)}`;
}

function formatScenarioCO2(gtco2Year) {
  if (!isFinite(gtco2Year)) return "—";

  const tonPerYear = gtco2Year * 1e9;

  if (Math.abs(tonPerYear) >= 1e6) {
    return `${(tonPerYear / 1e6).toFixed(2)} milyon ton CO₂ / yıl`;
  }

  if (Math.abs(tonPerYear) >= 1e3) {
    return `${(tonPerYear / 1e3).toFixed(2)} bin ton CO₂ / yıl`;
  }

  return `${tonPerYear.toFixed(0)} ton CO₂ / yıl`;
}

async function renderImpact(totalDownBytes) {
  const co2Text = document.getElementById("co2Text");
  const scenarioCo2Text = document.getElementById("scenarioCo2Text");
  const lagText = document.getElementById("lagText");
  const iceText = document.getElementById("iceText");

  const { kgco2 } = computeFootprintFromDownBytes(totalDownBytes);

  if (co2Text) {
    co2Text.textContent = fmtKg(kgco2);
  }

  const gtco2Year = computeScenarioGtCO2PerYear(kgco2);

  try {
    const meta = await loadImpactMeta();

    const bestLag = Number(meta.bestLag);
    const beta = Number(meta.coef_co2_lag);

    if (!isFinite(bestLag)) {
      throw new Error(`bestLag numeric değil: ${meta.bestLag}`);
    }

    if (!isFinite(beta)) {
      throw new Error(`coef_co2_lag numeric değil: ${meta.coef_co2_lag}`);
    }

    if (scenarioCo2Text) {
      scenarioCo2Text.textContent = formatScenarioCO2(gtco2Year);
    }

    if (lagText) {
      lagText.textContent = `${bestLag} yıl`;
    }

    const extraIceTotalGt = beta * gtco2Year * bestLag;
    const massStr = formatMassFromGt(extraIceTotalGt);
    const pools = calculatePoolsFromGt(extraIceTotalGt);
    const poolStr = formatPools(pools);

    if (iceText) {
      iceText.textContent = `Yaklaşık ${massStr} ek buzul kaybı / ${bestLag} yıl (${poolStr} olimpik havuz eşdeğeri)`;
    }
  } catch (e) {
    console.error("İklim etkisi hesap hatası:", e);

    if (scenarioCo2Text) scenarioCo2Text.textContent = "—";
    if (lagText) lagText.textContent = "—";
    if (iceText) iceText.textContent = "—";
  }
}

async function render() {
  const dateText = document.getElementById("dateText");
  const totalText = document.getElementById("totalText");

  const data = await storageGet(STORAGE_KEY);

  if (!data) {
    if (dateText) dateText.textContent = "—";
    if (totalText) totalText.textContent = "—";

    applyPopupBackground(bgdef);
    await renderImpact(0);
    return;
  }

  if (dateText) {
    dateText.textContent = `Tarih: ${prettyDate(data.day)}`;
  }

  if (totalText) {
    totalText.textContent = bytesToPretty(data.totalDownBytes || 0);
  }

  applyPopupBackground(pickBgByTotalBytes(data.totalDownBytes || 0));
  await renderImpact(data.totalDownBytes || 0);
}

async function resetToday() {
  const data = await storageGet(STORAGE_KEY);
  if (!data) return;

  const fresh = {
    day: data.day,
    totalDownBytes: 0,
    byDomain: data.byDomain || {}
  };

  chrome.storage.local.set({ [STORAGE_KEY]: fresh }, () => {
    render();
  });
}

document.addEventListener("DOMContentLoaded", () => {
  const refreshBtn = document.getElementById("refreshBtn");
  const resetBtn = document.getElementById("resetBtn");
  const updateBtn = document.getElementById("updateBtn");

  if (refreshBtn) {
    refreshBtn.addEventListener("click", () => {
      render();
    });
  }

  if (resetBtn) {
    resetBtn.addEventListener("click", () => {
      resetToday();
    });
  }

  if (updateBtn) {
    updateBtn.addEventListener("click", () => {
      render();
    });
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (!changes[STORAGE_KEY]) return;

    render();
  });

  render();
});