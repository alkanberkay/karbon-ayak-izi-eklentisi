const STORAGE_KEY = "transfer_v1";

function todayKey() {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function domainFromUrl(url) {
  try {
    return new URL(url).hostname || "bilinmeyen";
  } catch {
    return "bilinmeyen";
  }
}

function getHeader(responseHeaders, headerName) {
  if (!responseHeaders) return "";
  const name = headerName.toLowerCase();
  for (const h of responseHeaders) {
    if (h?.name?.toLowerCase() === name) return h.value || "";
  }
  return "";
}

function getContentLength(responseHeaders) {
  const v = getHeader(responseHeaders, "content-length");
  if (!v) return 0;
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? n : 0;
}

async function loadData() {
  const day = todayKey();
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  const data = stored[STORAGE_KEY];

  if (!data || data.day !== day) {
    const fresh = { day, totalDownBytes: 0, byDomain: {} };
    await chrome.storage.local.set({ [STORAGE_KEY]: fresh });
    return fresh;
  }

  if (!data.byDomain) data.byDomain = {};
  if (!Number.isFinite(data.totalDownBytes)) data.totalDownBytes = 0;

  return data;
}

async function addBytes(url, bytes) {
  if (!bytes || bytes <= 0) return;

  const data = await loadData();
  data.totalDownBytes += bytes;

  const domain = domainFromUrl(url);
  data.byDomain[domain] = (data.byDomain[domain] || 0) + bytes;

  await chrome.storage.local.set({ [STORAGE_KEY]: data });
}

const metaByRequestId = new Map();

chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    if (!details?.requestId || !details?.url) return;

    const len = getContentLength(details.responseHeaders);

    if (len > 0) {
      metaByRequestId.set(details.requestId, { len });
    }
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders"]
);

chrome.webRequest.onCompleted.addListener(
  async (details) => {
    try {
      if (!details?.requestId || !details?.url) return;

      if (details.fromCache) {
        metaByRequestId.delete(details.requestId);
        return;
      }

      const meta = metaByRequestId.get(details.requestId);
      metaByRequestId.delete(details.requestId);

      if (!meta) return;

      if (details.statusCode >= 200 && details.statusCode < 400) {
        await addBytes(details.url, meta.len);
      }
    } catch {

    }
  },
  { urls: ["<all_urls>"] }
);

chrome.webRequest.onErrorOccurred.addListener(
  (details) => {
    if (details?.requestId) metaByRequestId.delete(details.requestId);
  },
  { urls: ["<all_urls>"] }
);

chrome.runtime.onInstalled.addListener(async () => {
  await loadData();
});

chrome.runtime.onStartup.addListener(async () => {
  await loadData();
});
